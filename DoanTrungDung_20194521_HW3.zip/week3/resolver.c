#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include <netdb.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>


int main(int argc , char *argv[]){
    struct hostent *nameHost;
    char * host_name;
    struct in_addr **addr_list;
    int i=0;
    char *ip;
    /*
    if( argc < 2 )
    {
        printf("No Information found.\n");  
    }
    else
    {
        printf("First argument is: %s\n", argv[1]);
    }
    */
    
    host_name = argv[1];
    nameHost = gethostbyname(host_name);
    if (nameHost == NULL) { // do some error checking
        herror("gethostbyname"); // herror(), NOT perror()
        exit(1);
    }

    printf("Official name is: %s\n", nameHost->h_name);
    printf("IP address: %s\n", inet_ntoa(*(struct in_addr*)nameHost->h_addr));
    printf("All addresses: ");
    addr_list = (struct in_addr **)nameHost->h_addr_list;
    for(i = 0; addr_list[i] != NULL; i++) {
        strcpy(ip ,inet_ntoa(*addr_list[i]));
        printf(" %s ", ip);
    }
    printf("\n");


}
