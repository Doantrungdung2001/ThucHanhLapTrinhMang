run 
server 
	./server {Port}
client
	./client {Adrress} {Port} {username} {password}
 Vi du
 	./server 5500
 	./client 127.0.0.1 5500 hust hust123
